package com.dicoding.picodiploma.mystoryapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.picodiploma.mystoryapp.databinding.ActivityRegisterBinding
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelAuth
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelFactory

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private val factory: ViewModelFactory = ViewModelFactory.newInstance(this)
    private val viewModelAuth: ViewModelAuth by viewModels {
        factory
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(false)

        listenerSet()

        binding.register.setOnClickListener {
            if(validate()) {
                val name = binding.editNama.text.toString().trim()
                val email = binding.myEmailEdit.text.toString().trim()
                val pass = binding.myPassEdit.text.toString().trim()
                viewModelAuth.launcherRegistrasi(name, email, pass).observe(this, {
                    if (it != null) {
                        Toast.makeText(this, "${it.message}", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
                        showLoading(false)
                        startActivity(intent)
                    }
                    else {
                        showLoading(false)
                        Log.d("RegisterGagal", "Gagal Melakukan Registrasi")
                        Toast.makeText(this, "Data Sudah Terdaftar", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
        binding.tombolLogin.setOnClickListener {
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
        }
    }

    private fun validate():Boolean = validateNama() && validateEmail() && validatePassword()

    private fun listenerSet() {
        with(binding) {
            editNama.addTextChangedListener(validateMasukan(editNama))
            myEmailEdit.addTextChangedListener(validateMasukan(myEmailEdit))
            myPassEdit.addTextChangedListener(validateMasukan(myPassEdit))
        }
    }

    private fun validateNama():Boolean {
        if (binding.editNama.text.toString().trim().isEmpty()) {
            binding.editNama.error = "Tidak Boleh Kosong"
            binding.editNama.requestFocus()
            return false
        }
        else {
            return true
        }
    }

    private fun validateEmail():Boolean {
        if (binding.myEmailEdit.text.toString().trim().isEmpty()) {
            binding.myEmailEdit.error = "Tidak Boleh Kosong"
            binding.myEmailEdit.requestFocus()
            return false
        }
        else if (!HelperValidator.emailCheck(binding.myEmailEdit.text.toString())) {
            binding.myEmailEdit.error = "Tipe Email Tidak Sesuai"
            binding.myEmailEdit.requestFocus()
            return false
        }
        else {
            return true
        }
    }

    private fun validatePassword():Boolean {
        if (binding.myPassEdit.text.toString().trim().isEmpty()) {
            binding.myPassEdit.error = "Tidak Boleh Kosong"
            binding.myPassEdit.requestFocus()
            return false
        }
        else if (binding.myPassEdit.text.toString().length < 6) {
            binding.myPassEdit.error = "Password Minimal 6 Karakter"
            binding.myPassEdit.requestFocus()
            return false
        }
        else {
            return true
        }
    }

    inner class  validateMasukan(private val view: View): TextWatcher{
        override fun afterTextChanged(p0: Editable?) {}
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            when (view.id) {
                R.id.edit_nama -> {
                    validateNama()
                }
                R.id.my_email_edit -> {
                    validateEmail()
                }
                R.id.my_pass_edit -> {
                    validatePassword()
                }
            }
        }
    }

    private fun showLoading(state: Boolean) {
        if (state == true) {
            binding.progressBar.visibility = View.VISIBLE
        }
        else {
            binding.progressBar.visibility = View.GONE
        }
    }

}