package com.dicoding.picodiploma.mystoryapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.mystoryapp.adapter.AdapterLoading
import com.dicoding.picodiploma.mystoryapp.adapter.AdapterStories
import com.dicoding.picodiploma.mystoryapp.databinding.ActivityHomeBinding
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelAwal
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelFactory

class HomeActivity : AppCompatActivity() {

    private lateinit var preferenceSession: PreferenceSession
    private lateinit var binding: ActivityHomeBinding
    private var token:String? = ""
    private val factory:ViewModelFactory = ViewModelFactory.newInstance(this)
    private val viewModelAwal:ViewModelAwal by viewModels{
        factory
    }

    companion object{
        const val EXTRA_RESULT="extra_person"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "List Stories"
        binding.listCerita.layoutManager = LinearLayoutManager(this)
        val sessionLogin = intent.getParcelableExtra<SessionLogin>(EXTRA_RESULT) as SessionLogin
        token = sessionLogin.token

        adapterStoriesSet(sessionLogin)
        binding.tambahCerita.setOnClickListener {
            val intent = Intent(this@HomeActivity, AddStoryActivity::class.java)
            intent.putExtra(AddStoryActivity.LOGIN_SESSION, sessionLogin)
            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        itemResponse(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun itemResponse(selectedItem: Int) {
        when (selectedItem) {
            R.id.logout -> {
                logoutNow()
            }
            R.id.modeMaps -> {
                mapsMode()
            }
        }
    }

    private fun mapsMode() {
        val intent = Intent(this@HomeActivity, MapsActivity::class.java)
        preferenceSession = PreferenceSession(this)
        intent.putExtra(MapsActivity.TOKEN, preferenceSession.sesiGet())
        startActivity(intent)
    }

    private fun logoutNow() {
        preferenceSession = PreferenceSession(this)
        preferenceSession.sesiDelete()
        Log.d(".HomeActivity", "Periksa : ${preferenceSession.sesiGet()}")
        val toLogin = Intent(this@HomeActivity, LoginActivity::class.java)
        startActivity(toLogin)
        finish()
    }

    private fun adapterStoriesSet(sessionLogin: SessionLogin) {
        showLoading(true)
        val adapterStories = AdapterStories()
        binding.listCerita.adapter = adapterStories.withLoadStateFooter(
            footer = AdapterLoading {
                adapterStories.retry()
            }
        )
        viewModelAwal.storiesGet(sessionLogin).observe(this, {
            Log.d(".HomeActivity", "Data Cerita : $it")
            adapterStories.submitData(lifecycle, it)
        })
        showLoading(false)
    }

    private fun tokenGet():String? {
        return token
    }

    private fun showLoading(state: Boolean) {
        if (state == true) {
            binding.progressBar.visibility = View.VISIBLE
        }
        else {
            binding.progressBar.visibility = View.GONE
        }
    }
}