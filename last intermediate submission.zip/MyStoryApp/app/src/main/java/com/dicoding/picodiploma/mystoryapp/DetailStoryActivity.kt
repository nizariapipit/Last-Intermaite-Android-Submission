package com.dicoding.picodiploma.mystoryapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.mystoryapp.api.ListStory
import com.dicoding.picodiploma.mystoryapp.databinding.ActivityDetailStoryBinding

class DetailStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailStoryBinding
    companion object {
        const val OBJECT = "object"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(true)

        val story = intent.getParcelableExtra<ListStory>(OBJECT) as ListStory
        Log.d("DetailStory", "$story")

        with(binding){
            nama.text = story.name
            deskripsi.text = story.description
            Glide.with(this@DetailStoryActivity)
                .load(story.photoUrl)
                .into(imgStories)
        }
        showLoading(false)
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        }else{
            binding.progressBar.visibility = View.GONE
        }
    }
}