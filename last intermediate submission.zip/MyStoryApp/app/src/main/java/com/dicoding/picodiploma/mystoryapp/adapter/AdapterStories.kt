package com.dicoding.picodiploma.mystoryapp.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.mystoryapp.DetailStoryActivity
import com.dicoding.picodiploma.mystoryapp.api.ListStory
import com.dicoding.picodiploma.mystoryapp.databinding.ListAdapterStoriesBinding

class AdapterStories : PagingDataAdapter<ListStory, AdapterStories.ListViewHolder>(DIFF_CALLBACK){

    companion object{
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListStory>(){
            override fun areItemsTheSame(oldItem: ListStory, newItem: ListStory): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(oldItem: ListStory, newItem: ListStory): Boolean {
                return oldItem.id == newItem.id
            }

        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ListViewHolder {
        val bindLayer = ListAdapterStoriesBinding.inflate(LayoutInflater.from(viewGroup.context),viewGroup, false)
        return ListViewHolder(bindLayer)
    }

    override fun onBindViewHolder(holder: AdapterStories.ListViewHolder, position: Int) {
        val data = getItem(position)
        if (data != null) {
            holder.bind(data)
        }
    }

    //override fun getItemCount(): Int = mStories.size

    inner class ListViewHolder(private val binding: ListAdapterStoriesBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(listStory: ListStory) {
            with(binding) {
                Glide.with(itemView.context)
                    .load(listStory.photoUrl)
                    .into(imgStories)
                username.text = listStory.name

                val compat: ActivityOptionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    itemView.context as Activity,
                    Pair(binding.imgStories, "imgTrans"),
                    Pair(binding.username, "username")
                )

                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailStoryActivity::class.java)
                    intent.putExtra(DetailStoryActivity.OBJECT, listStory)
                    itemView.context.startActivity(intent, compat.toBundle())
                }
            }
        }
    }
}