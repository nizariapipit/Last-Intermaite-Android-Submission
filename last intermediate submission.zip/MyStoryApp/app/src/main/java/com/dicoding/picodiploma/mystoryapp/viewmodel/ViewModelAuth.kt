package com.dicoding.picodiploma.mystoryapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.mystoryapp.api.LoginResponse
import com.dicoding.picodiploma.mystoryapp.api.RegisterResponse
import com.dicoding.picodiploma.mystoryapp.paging.RepositoryStory

class ViewModelAuth (private val repositoryStory: RepositoryStory): ViewModel() {

    fun launcherRegistrasi(name:String, email: String, password:String):LiveData<RegisterResponse?> {
        repositoryStory.launcherRepoRegister(name, email, password)
        return repositoryStory.registerResponseGet()
    }

    fun launcherLogin(email: String, password: String):LiveData<LoginResponse?> {
        repositoryStory.launcherRepoLogin(email, password)
        return repositoryStory.loginResponseGet()
    }
}