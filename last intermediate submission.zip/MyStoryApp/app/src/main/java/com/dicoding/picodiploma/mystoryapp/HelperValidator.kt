package com.dicoding.picodiploma.mystoryapp

import android.util.Patterns

object HelperValidator {
    fun emailCheck(email: String):Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}