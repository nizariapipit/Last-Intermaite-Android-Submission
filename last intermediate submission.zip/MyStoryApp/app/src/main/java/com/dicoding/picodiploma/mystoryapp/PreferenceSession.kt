package com.dicoding.picodiploma.mystoryapp

import android.content.Context
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin

class PreferenceSession (context: Context) {
    companion object {
        private const val LOGIN_PREF = "login_pref"
        private const val NAMA = "nama"
        private const val TOKEN = "token"
        private const val ID_PENGGUNA = "id_pengguna"
     }

    private val preference = context.getSharedPreferences(LOGIN_PREF, Context.MODE_PRIVATE)

    fun sesiSet(sessionLogin: SessionLogin) {
        val prefSes = preference.edit()
        prefSes.putString(NAMA, sessionLogin.name)
        prefSes.putString(TOKEN, sessionLogin.token)
        prefSes.putString(ID_PENGGUNA, sessionLogin.userId)
        prefSes.apply()
    }

    fun sesiGet(): SessionLogin {
        val sessionLogin = SessionLogin()
        sessionLogin.name = preference.getString(NAMA, "")
        sessionLogin.token = preference.getString(TOKEN, "")
        sessionLogin.userId = preference.getString(ID_PENGGUNA, "")
        return  sessionLogin
    }

    fun sesiDelete() {
        val prefSes = preference.edit()
        prefSes.clear().apply()
    }
}