package com.dicoding.picodiploma.mystoryapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.mystoryapp.api.ListStory
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin
import com.dicoding.picodiploma.mystoryapp.paging.RepositoryStory

class MapsActivityViewModel (private val repositoryStory: RepositoryStory):ViewModel() {
    fun mapsListStoryGet(sessionLogin: SessionLogin):LiveData<List<ListStory>> {
        repositoryStory.mapsListStorySet(sessionLogin)
        return repositoryStory.mapsListStoryGet()
    }
}