package com.dicoding.picodiploma.mystoryapp.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.paging.PagingData
import com.dicoding.picodiploma.mystoryapp.api.ListStory
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin
import com.dicoding.picodiploma.mystoryapp.paging.RepositoryStory

class ViewModelAwal(private val repositoryStory: RepositoryStory): ViewModel() {

    fun storiesGet(sessionLogin: SessionLogin):LiveData<PagingData<ListStory>> {
        Log.d("Lihat Data", "${sessionLogin.token}\n${repositoryStory.userGet(sessionLogin)}")
        return repositoryStory.userGet(sessionLogin)
    }
}