package com.dicoding.picodiploma.mystoryapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.dicoding.picodiploma.mystoryapp.databinding.ActivityMapsBinding
import com.dicoding.picodiploma.mystoryapp.viewmodel.MapsActivityViewModel
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelFactory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    companion object {
        const val TOKEN = "token"
    }

    private lateinit var binding: ActivityMapsBinding
    private lateinit var mMap: GoogleMap
    private lateinit var mPreferenceSession: PreferenceSession
    private val factory: ViewModelFactory = ViewModelFactory.newInstance(this)
    private val mapsActivityViewModel: MapsActivityViewModel by viewModels {
        factory
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)

        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.maps) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mPreferenceSession = PreferenceSession(this)
        mMap = googleMap

        mapsActivityViewModel.mapsListStoryGet(mPreferenceSession.sesiGet()).observe(this, {
            var latlngarr = ArrayList<LatLng>()
            for (listStory in it) {
                val latLng = LatLng(listStory.lat, listStory.lon)
                latlngarr.add(latLng)
                mMap.addMarker(
                    MarkerOptions().position(latLng)
                        .position(latLng)
                        .title("Posisi ${listStory.name}")
                        .snippet("Posisi ${listStory.name}")
                )
                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng))
            }
            Log.d("kumpulan lat lng", "$latlngarr")
        })
        getMyLocation()
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }

    private fun getMyLocation(){
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled=true
        }
        else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }


}