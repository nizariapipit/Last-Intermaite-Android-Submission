package com.dicoding.picodiploma.mystoryapp.paging

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.picodiploma.mystoryapp.api.*
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RepositoryStory(private  val apiService: ApiService) {

    companion object {
        @Volatile
        private var instance: RepositoryStory? = null
        fun newInstance(
            apiService: ApiService
        ): RepositoryStory = instance?: synchronized(this) {
            instance?: RepositoryStory(apiService)
        }.also { instance = it }
    }

    val loginResponse = MutableLiveData<LoginResponse?>()
    val registerResponse = MutableLiveData<RegisterResponse?>()
    val listStoryMaps = MutableLiveData<List<ListStory>>()

    fun userGet(sessionLogin: SessionLogin): LiveData<PagingData<ListStory>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            pagingSourceFactory = {
                PaginationResource(apiService, sessionLogin)
            }
        ).liveData
    }

    fun launcherRepoRegister(name:String, email:String, password:String) {
        val launchRegis = ApiConfig.getApiService().postRegister(name,email, password)
        launchRegis.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                if(response.isSuccessful) {
                    val responseBody = response.body()
                    if(responseBody != null && !responseBody.error) {
                        Log.d(".RegisterActivity", "Registrasi Anda Berhasil $responseBody")
                        registerResponse.postValue(responseBody)
                    }
                }
                else {
                    val errorMessage = when (response.code()) {
                        401 -> "${response.code()} : Bad Request"
                        403 -> "${response.code()} : Forbidden"
                        404 -> "${response.code()} : Not Found"
                        else -> "${response.code()} : $response"
                    }
                    Log.e(".RegisterActivity", "$errorMessage")
                    registerResponse.postValue(response.body())
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                Log.e(".RegisterActivity", "Kesalahan pada Retrofit")
            }
        })
    }

    fun launcherRepoLogin(email:String, password: String) {
        val launchLoginer = ApiConfig.getApiService().login(email, password)
        launchLoginer.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if(response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null && !responseBody.error) {
                        Log.d(".LoginActivity", "Login Anda Berhasil $responseBody")
                        loginResponse.postValue(responseBody)
                    }
                }
                else {
                    Log.e(".LoginActivity", "Login Anda Gagal ${response.message()}")
                    loginResponse.postValue(response.body())
                }
            }
            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                Log.e(".RegisterActivity", "Kesalahan pada Retrofit")
            }
        })
    }

    fun mapsListStorySet(sessionLogin: SessionLogin) {
        val storyMaps = ApiConfig.getApiService().getStoriesMaps( "Bearer ${sessionLogin.token}", null,null, 1)
        storyMaps.enqueue(object : Callback<StoriesResponse> {
            override fun onResponse(
                call: Call<StoriesResponse>,
                response: Response<StoriesResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null && !responseBody.error) {
                        listStoryMaps.postValue(responseBody.listStory)
                    }
                }
                else {
                    Log.e(".LoginActivity", "Login Anda Gagal ${response.message()}")
                    listStoryMaps.postValue(response.body()!!.listStory)
                }
            }

            override fun onFailure(call: Call<StoriesResponse>, t: Throwable) {
                Log.e(".MapsActivity", "Kesalahan pada Retrofit")
            }
        })
    }

    fun loginResponseGet():LiveData<LoginResponse?> {
        return loginResponse
    }

    fun registerResponseGet():LiveData<RegisterResponse?> {
        return registerResponse
    }

    fun mapsListStoryGet():LiveData<List<ListStory>> {
        return listStoryMaps
    }
}