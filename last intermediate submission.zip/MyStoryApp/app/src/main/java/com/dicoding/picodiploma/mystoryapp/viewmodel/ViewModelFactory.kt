package com.dicoding.picodiploma.mystoryapp.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.mystoryapp.injection.Injection
import com.dicoding.picodiploma.mystoryapp.paging.RepositoryStory

class ViewModelFactory private constructor(private val repositoryStory: RepositoryStory):ViewModelProvider.Factory{

    companion object{
        @Volatile
        private var instance:ViewModelFactory? = null
        fun newInstance(context: Context):ViewModelFactory = instance?: synchronized(this) {
            instance ?: ViewModelFactory(Injection.provideRespository(context))
        }.also { instance = it }
    }

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ViewModelAwal::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ViewModelAwal(repositoryStory) as T
        }
        else if (modelClass.isAssignableFrom(MapsActivityViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MapsActivityViewModel(repositoryStory) as T
        }
        else if (modelClass.isAssignableFrom(ViewModelAuth::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ViewModelAuth(repositoryStory) as T
        }
        throw IllegalArgumentException("Unknown ViewModel Class")
    }
}