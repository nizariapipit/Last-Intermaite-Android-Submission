package com.dicoding.picodiploma.mystoryapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.picodiploma.mystoryapp.HelperValidator.emailCheck
import com.dicoding.picodiploma.mystoryapp.databinding.ActivityLoginBinding
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelAuth
import com.dicoding.picodiploma.mystoryapp.viewmodel.ViewModelFactory

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var sessionLogin: SessionLogin
    private val factory:ViewModelFactory = ViewModelFactory.newInstance(this)
    private val viewModelAuth: ViewModelAuth by viewModels{
        factory
    }
    private lateinit var preferenceSession: PreferenceSession

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Login"

        animatedSesi()
        preferenceSession = PreferenceSession(this)
        showLoading(false)

        if(preferenceSession.sesiGet().name!="") {
            val loginNew = preferenceSession.sesiGet()
            val intent = Intent(this@LoginActivity, HomeActivity::class.java)
            intent.putExtra(HomeActivity.EXTRA_RESULT, loginNew)
            startActivity(intent)
            finish()
        }

        listenerSet()

        binding.tombolLogin.setOnClickListener {
            if (validate()) {
                showLoading(true)
                val email = binding.myEmailEdit.text.toString().trim()
                val password = binding.myPassEdit.text.toString().trim()
                viewModelAuth.launcherLogin(email, password).observe(this, {
                    if (it != null) {
                        if (it.error == true) {
                            showLoading(false)
                            Toast.makeText(this, "${it.message}", Toast.LENGTH_SHORT).show()
                        }
                        else {
                            sesiSimpan(it.loginResult.name, it.loginResult.token, it.loginResult.userId)
                        }
                    }
                    else {
                        showLoading(false)
                        Toast.makeText(this, "Email atau Password Anda Salah", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }

        binding.register.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }
    }



    private fun animatedSesi() {
        val email = ObjectAnimator.ofFloat(binding.email, View.ALPHA, 1f).setDuration(1000)
        val emailEditText = ObjectAnimator.ofFloat(binding.myEmailEdit, View.ALPHA, 1f).setDuration(1000)
        val password = ObjectAnimator.ofFloat(binding.password, View.ALPHA, 1f).setDuration(1000)
        val passwordEditText = ObjectAnimator.ofFloat(binding.myPassEdit, View.ALPHA, 1f).setDuration(1000)
        val loginButton = ObjectAnimator.ofFloat(binding.tombolLogin, View.ALPHA, 1f).setDuration(1000)
        val register = ObjectAnimator.ofFloat(binding.register, View.ALPHA, 1f).setDuration(1000)

        AnimatorSet().apply {
            playTogether(email, emailEditText)
            startDelay = 500
        }.start()

        AnimatorSet().apply {
            playTogether(password, passwordEditText)
            startDelay = 500
        }.start()

        AnimatorSet().apply{
            playSequentially(
                loginButton,
                register
            )
            startDelay = 500
        }.start()
        ObjectAnimator.ofFloat(binding.register, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()
    }

    private fun sesiSimpan(name: String, token: String, userId: String){
        preferenceSession = PreferenceSession(this)
        sessionLogin = SessionLogin()
        sessionLogin.name = name
        sessionLogin.token = token
        sessionLogin.userId = userId
        preferenceSession.sesiSet(sessionLogin)
        toHome()
    }

    private fun toHome() {
        preferenceSession = PreferenceSession(this)
        val loginNew = preferenceSession.sesiGet()
        val intent = Intent(this@LoginActivity, HomeActivity::class.java)
        Toast.makeText(this, "tervalidasi", Toast.LENGTH_SHORT).show()
        intent.putExtra(HomeActivity.EXTRA_RESULT, loginNew)
        startActivity(intent)
        finish()
    }

    private fun validate():Boolean = emailValidation() && passwordValidation()

    private fun listenerSet() {
        with(binding) {
            myEmailEdit.addTextChangedListener(inputValidation(myEmailEdit))
            myPassEdit.addTextChangedListener(inputValidation(myPassEdit))
        }
    }

    private fun emailValidation():Boolean {
        if (binding.myEmailEdit.text.toString().trim().isEmpty()) {
            binding.myEmailEdit.error = "Belum Terisi"
            binding.myEmailEdit.requestFocus()
            return false
        }
        else if (!emailCheck(binding.myEmailEdit.text.toString())) {
            binding.myEmailEdit.error = "Tipe Email Tidak Valid"
            binding.myEmailEdit.requestFocus()
            return false
        }
        else{
            return true
        }
    }

    private fun passwordValidation():Boolean {
        if (binding.myPassEdit.text.toString().trim().isEmpty()) {
            binding.myPassEdit.error = "Belum Terisi"
            binding.myPassEdit.requestFocus()
            return false
        }
        else if (binding.myPassEdit.text.toString().length < 6) {
            binding.myPassEdit.error = "Password Minimal Terdiri dari 6 Karakter"
            binding.myPassEdit.requestFocus()
            return false
        }
        else {
            return true
        }
    }

    inner class inputValidation(private val view: View):TextWatcher {
        override fun afterTextChanged(s: Editable?) {}
        override fun beforeTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {
            when (view.id) {
                R.id.my_email_edit -> {
                    emailValidation()
                }
                R.id.my_pass_edit -> {
                    passwordValidation()
                }
            }
        }
    }

    private fun showLoading(state: Boolean) {
        if (state == true) {
            binding.progressBar.visibility = View.VISIBLE
        }
        else {
            binding.progressBar.visibility = View.GONE
        }
    }
}