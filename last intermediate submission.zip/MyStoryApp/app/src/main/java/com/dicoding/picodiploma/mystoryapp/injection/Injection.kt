package com.dicoding.picodiploma.mystoryapp.injection

import android.content.Context
import com.dicoding.picodiploma.mystoryapp.api.ApiConfig
import com.dicoding.picodiploma.mystoryapp.paging.RepositoryStory

object Injection {
    fun provideRespository(context: Context): RepositoryStory {
        val apiService = ApiConfig.getApiService()
        return  RepositoryStory.newInstance(apiService)
    }
}