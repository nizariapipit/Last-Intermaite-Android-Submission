package com.dicoding.picodiploma.mystoryapp.paging

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.dicoding.picodiploma.mystoryapp.api.ApiService
import com.dicoding.picodiploma.mystoryapp.api.ListStory
import com.dicoding.picodiploma.mystoryapp.model.SessionLogin
import okio.IOException

class PaginationResource(private val apiService: ApiService, sessionLogin: SessionLogin) : PagingSource<Int, ListStory>() {

    private companion object{
        const val INITIAL_PAGE_INDEX = 1
    }

    private var sessionLoginLocal: SessionLogin = sessionLogin
    private var listStory = ArrayList<ListStory>()

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, ListStory> {
        return try {
            val page =  params.key ?: INITIAL_PAGE_INDEX
            val responseData = apiService.getStories("Bearer ${sessionLoginLocal.token}", page, params.loadSize)

            LoadResult.Page(
                data = responseData.listStory,
                prevKey = if(page == 1) null else page - 1,
                nextKey = if (responseData.listStory.isNullOrEmpty()) null else page + 1
            )
        } catch (exception: IOException) {
            LoadResult.Error(exception)
        } catch (exception : IOException){
            LoadResult.Error(exception)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, ListStory>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            val anchorPage = state.closestPageToPosition(anchorPosition)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }
}